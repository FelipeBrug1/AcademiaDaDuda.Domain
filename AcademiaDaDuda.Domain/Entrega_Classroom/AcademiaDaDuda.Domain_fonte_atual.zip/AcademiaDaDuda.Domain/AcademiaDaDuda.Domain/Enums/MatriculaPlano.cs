﻿//  Felipe Antonio Brüggemann

namespace AcademiaDaDuda.Domain.Enums
{
    public enum MatriculaPlano
    {
        Mensal = 0,
        Trimestral = 1,
        Semestral = 2,
        Anual = 3
    }
}
